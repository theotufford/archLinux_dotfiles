Mappings for [nullbits](https://nullbits.co/) keyboards,
often based on the [BIT-C pro micro MCU](https://nullbits.co/bit-c/).
